// SHKM App Service Worker
// Verzija cache-a – povećaj kad pushaš nove verzije
const CACHE_NAME = 'shkm-2025-v1';
const OFFLINE_URL = '/index.html';

// Sve datoteke koje idemo keširati za offline rad
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  // Google Fonts – ako su dostupne pri prvom učitavanju
];

// ============================================================
// INSTALL – preuzmi sve statičke resurse
// ============================================================
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('[SW] Caching static assets');
      return cache.addAll(STATIC_ASSETS).catch(err => {
        // Ako neki resurs ne uspije, nastavi dalje
        console.warn('[SW] Some assets failed to cache:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// ============================================================
// ACTIVATE – briši stare cache verzije
// ============================================================
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => {
          console.log('[SW] Deleting old cache:', key);
          return caches.delete(key);
        })
      )
    ).then(() => self.clients.claim())
  );
});

// ============================================================
// FETCH – strategija: Cache First, fallback na Network
// ============================================================
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  // Preskoči ne-GET zahtjeve
  if (request.method !== 'GET') return;

  // Za navigacijske zahtjeve – vrati index.html iz cachea
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).catch(() => caches.match(OFFLINE_URL))
    );
    return;
  }

  // Za statičke resurse – Cache First
  event.respondWith(
    caches.match(request).then(cached => {
      if (cached) return cached;
      
      return fetch(request).then(response => {
        // Keširaj valjane odgovore
        if (response && response.status === 200 && response.type === 'basic') {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
        }
        return response;
      }).catch(() => {
        // Ako je slika i nije dostupna, vrati placeholder
        if (request.destination === 'image') {
          return new Response('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect width="100" height="100" fill="#eee"/><text x="50" y="55" text-anchor="middle" fill="#999" font-size="12">Offline</text></svg>', { headers: { 'Content-Type': 'image/svg+xml' } });
        }
      });
    })
  );
});

// ============================================================
// BACKGROUND SYNC – za buduće notifikacije
// ============================================================
self.addEventListener('sync', event => {
  if (event.tag === 'sync-news') {
    console.log('[SW] Background sync: news');
    // Ovdje bi išao fetch novih vijesti s API-ja
  }
});

// ============================================================
// PUSH NOTIFICATIONS – skeleton za budući razvoj
// ============================================================
self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  const title = data.title || 'SHKM 2025';
  const options = {
    body: data.body || 'Nova obavijest sa susreta',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    vibrate: [200, 100, 200],
    data: { url: data.url || '/' }
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(
    clients.openWindow(event.notification.data.url || '/')
  );
});
