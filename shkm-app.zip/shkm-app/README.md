# SHKM 2025 – Aplikacija za Susret hrvatske katoličke mladeži

## Sadržaj aplikacije

Potpuna Progressive Web App (PWA) za SHKM 2025, Požeška biskupija. Radi offline, instalira se na Android i iOS, dizajnirana za mlade korisnike.

---

## Pokretanje aplikacije

### Opcija 1 – Python (najbrže, bez instalacije)
```bash
cd shkm-app
python3 -m http.server 8080
```
Otvori browser na: `http://localhost:8080`

### Opcija 2 – Node.js
```bash
npx serve shkm-app
```

### Opcija 3 – Live Server (VS Code)
Instaliraj ekstenziju "Live Server", desni klik na `index.html` → "Open with Live Server"

---

## Instalacija na mobitel

### Android (Chrome)
1. Otvori URL aplikacije u Chrome
2. Klikni na "Instaliraj" baner koji se pojavi
3. Ili: ⋮ izbornik → "Dodaj na početni zaslon"

### iOS (Safari)
1. Otvori URL u Safari
2. Klikni na gumb "Dijeli" (kvadrat sa strelicom)
3. Odaberi "Dodaj na početni zaslon"

---

## Struktura projekta

```
shkm-app/
├── index.html       ← Sva logika, UI i podaci (single-file PWA)
├── sw.js            ← Service Worker (offline podrška)
├── manifest.json    ← PWA manifest (ikone, naziv, teme)
├── icons/
│   ├── icon-192.png ← Ikona za Android/iOS
│   └── icon-512.png ← Ikona za splash screen
└── README.md        ← Ove upute
```

---

## Značajke

| Značajka | Status |
|---|---|
| Početna stranica s odbrojavanjem | ✅ |
| Interaktivna karta Požege | ✅ (SVG placeholder) |
| Molitvenik (8 molitvi) | ✅ Offline |
| Himna – player + tekst | ✅ (audio placeholder) |
| Vijesti / obavijesti | ✅ Mock podaci |
| Vodič za svetu misu | ✅ 10 koraka |
| Kontakti + hitni brojevi | ✅ |
| Raspored (Petak + Subota) | ✅ Offline |
| PWA – instalacija | ✅ |
| Offline podrška | ✅ Service Worker |
| Pretraživanje | ✅ |
| Responsive dizajn | ✅ Mobile-first |

---

## Dodavanje pravih podataka

### Molitve
U `index.html`, pronađi `DATA.prayers` i dodaj/uredi unose:
```js
{ id:'nova', name:'Naziv molitve', desc:'Opis', text:`<p>Tekst molitve</p>` }
```

### Raspored
U `DATA.schedule[0].events` (Petak) ili `[1].events` (Subota):
```js
{ time:'14:00', name:'Naziv događaja', loc:'Lokacija', tag:'Kategorija', color:'gold' }
```
Boje: `'gold'`, `'navy'`, `'green'`

### Vijesti
Dodaj u `DATA.news`:
```js
{ id:6, title:'Naslov', date:'1. svibnja 2025.', cat:'Kategorija', excerpt:'Tekst...', icon:'🎉', featured:false }
```

### Karta – prave koordinate
Zamijeni SVG placeholder s Google Maps embed:
```html
<iframe src="https://www.google.com/maps/embed?pb=..." width="100%" height="100%"></iframe>
```
Ili dodaj lokacijama (`DATA.locations`) pravi `lat`/`lng` i koristi Google Maps JS API.

### Audio himna
U HTML pronađi `<div class="anthem-player">` i dodaj:
```html
<audio id="hymnAudio" src="audio/himna.mp3" preload="auto"></audio>
```
Zatim u JS poveži s `togglePlay()` funkcijom.

---

## Proširenje aplikacije

### Push notifikacije
`sw.js` već ima skeleton za push notifikacije. Spoji s Firebase Cloud Messaging:
1. Dodaj Firebase SDK
2. Zatraži dozvolu: `Notification.requestPermission()`
3. Spremi token i šalji poruke s Firebase konzole

### Backend / CMS
Vijesti se trenutno učitavaju iz mock podataka. Za pravi CMS:
1. Postavi jednostavan REST API (npr. WordPress, Strapi, Google Sheets API)
2. U `renderNews()` zamijeni `DATA.news` s `fetch('https://api.../news')`
3. Service Worker automatski kešira odgovore

### Google Maps integracija
1. Dobij API ključ na console.cloud.google.com
2. Zamijeni SVG kartu s:
```html
<div id="gmap" style="flex:1"></div>
<script src="https://maps.googleapis.com/maps/api/js?key=TVOJ_KLJUČ&callback=initMap"></script>
```

---

## Tehnički detalji

- **Framework**: Vanilla JS (bez dependencija) – brzo, stabilno, offline
- **CSS**: Custom properties, mobile-first, smooth animations
- **Offline**: Service Worker s Cache-First strategijom
- **Instalacija**: Web App Manifest s ikonama i shortcutima
- **Fontovi**: Playfair Display (display) + DM Sans (body) – Google Fonts
- **Veličina**: ~40KB HTML + SW + Manifest (bez vanjskih resursa)

---

## Kontakt i razvoj

Razvijeno za Požešku biskupiju – SHKM 2025.  
Proširivanje: dodaj novi `<div class="page" id="page-novo">` i odgovarajući tab u `.bottom-nav`.

**Napomena**: Za produkcijsku verziju preporučamo hosting na HTTPS domenoM (obavezno za PWA installability).
