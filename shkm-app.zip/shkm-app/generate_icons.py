from PIL import Image, ImageDraw, ImageFont
import os

os.makedirs('icons', exist_ok=True)

def make_icon(size, path):
    img = Image.new('RGBA', (size, size), (26, 58, 92, 255))
    draw = ImageDraw.Draw(img)
    
    # Draw cross
    cw = size // 10
    cx, cy = size // 2, size // 2
    ch = int(size * 0.45)
    cw2 = int(size * 0.28)
    # Vertical
    draw.rectangle([cx - cw//2, cy - ch//2, cx + cw//2, cy + ch//2], fill=(201, 146, 42, 255))
    # Horizontal
    draw.rectangle([cx - cw2//2, cy - ch//6, cx + cw2//2, cy + ch//6], fill=(201, 146, 42, 255))
    
    # Border radius simulation via rounded corners
    img.save(path, 'PNG')

make_icon(192, 'icons/icon-192.png')
make_icon(512, 'icons/icon-512.png')
print("Icons generated!")
